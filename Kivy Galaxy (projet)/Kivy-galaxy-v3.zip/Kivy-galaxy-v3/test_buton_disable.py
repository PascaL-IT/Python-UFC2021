# Ref. https://likegeeks.com/kivy-tutorial/#:~:text=button%20like%20this%3A-,Disable%20Kivy%20Button,the%20disabled%20property%20to%20True.
#      https://kivy.org/doc/stable/api-kivy.uix.button.html
from kivy.uix.button import Button

from kivy.app import App

from functools import partial

class KivyButton(App):

    def disable(self, instance, *args):
        instance.disabled = True

    def update(self, instance, *args):
        instance.text = "I am Disabled!"
        instance.disabled = False

    def get_state(self, *args):
        print(f"{self.on_state}")

    def build(self):
        mybtn = Button(text="Click me to disable")
        mybtn.bind(on_press=partial(self.update, mybtn))
        mybtn.bind(on_release=partial(self.update, mybtn))
        mybtn.bind(state=self.get_state)
        return mybtn

KivyButton().run()